﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PecuniaWPF
{
    public class Common
    {
        public static Guid CurrentUserID { get; set; }
    }
}

