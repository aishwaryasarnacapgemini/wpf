﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        
        Admin admin = new Admin();
        AdminBL adminBL = new AdminBL();

        public Window1()
        {
            InitializeComponent();
        }


        private async Task<Admin> Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                admin = await adminBL.GetAdminByAdminIDBL(Common.CurrentUserID);
                adminID.Text = admin.AdminID.ToString();
                adminName.Text = admin.AdminName;
                adminEmail.Text = admin.Email;
                adminCreationDate.Text = admin.CreationDateTime.ToString();
                adminLastModifiedDateTime.Text = admin.LastModifiedDateTime.ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
              
            }
            return admin;

        }

        private void LogOut_Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Customer_Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Employees_Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var employees = new Employees();
                employees.Show();
                this.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
