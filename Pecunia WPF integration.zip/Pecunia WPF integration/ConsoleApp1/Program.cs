﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Test
    {
        public static async Task Menu()
        {

            Guid x;
            Guid.TryParse("9C342DD2-2D52-47F8-A32D-AAE2C5BC5201", out x);
            Admin admin = new Admin() {
                AdminID = x,
                AdminName = "Admin",
            Email = "admin@capgemini.com",
            Password = "Manager456",
            CreationDateTime = DateTime.Now,
            LastModifiedDateTime = DateTime.Now
                
            };

            AdminBL adminBL = new AdminBL();
            await adminBL.UpdateAdminBL(admin);
            
        }
    }

    class Program
    {
        [STAThread]
        public static void Main()
        {
            Test.Menu().Wait();
        }
    }
}
