﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Data;

namespace ExampleWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            dtEntryDate.SelectedDate = DateTime.Now;
            dgvData.CanUserAddRows = false;
            dgvData.CanUserDeleteRows = false;
            loadData();
        }

        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(txtName.Text);

            SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon); //retrieve settings
            try
            {
                sqlConnection.Open();
                MessageBox.Show("Connected to database server");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            /*not used because it lacks concurrency
            string query = "select * from Products";
            DataSet dataSet = new DataSet();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
            try
            {
                sqlDataAdapter.Fill(dataSet);
                dataSet.Tables[0].Rows[0]["Product_Name"] = txtName.Text;
                sqlDataAdapter.Update(dataSet);
                dataSet.Tables[0].AcceptChanges();
                MessageBox.Show("Data Saved");
            }
            catch (Exception exp)
            {

                MessageBox.Show(exp.Message);
            }
            */

            string query = "insert into Products values(8,@name,@type, @date,@active)";
            SqlCommand sqlCommand = new SqlCommand(query);
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.Parameters.AddWithValue("@name", txtName.Text);
            sqlCommand.Parameters.AddWithValue("@type", cmbType.Text);
            sqlCommand.Parameters.AddWithValue("@type", dtEntryDate.SelectedDate);
            sqlCommand.Parameters.AddWithValue("@type", chkActive.IsChecked);


            sqlCommand.Connection = sqlConnection;
            try
            {
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("data saved");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TxtName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void loadData()
        {
            SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon); //retrieve settings
            try
            {
                sqlConnection.Open();
                MessageBox.Show("Connected to database server");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            string query = "select * from Products";
            DataSet dataSet = new DataSet();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
            try
            {
                sqlDataAdapter.Fill(dataSet);
                dgvData.ItemsSource = dataSet.Tables[0].DefaultView;
                lblStatus.Content = "fetched rows" + dataSet.Tables[0].Rows.Count.ToString();
                MessageBox.Show("data saved");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            loadData();
        }

        private void DgvData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgvData.SelectedIndex;
            if (rowindex < 0)
                return;
            txtID.Text = getCellData(dgvData, rowindex, 0);
            txtName.Text = getCellData(dgvData, rowindex, 1);
            cmbType.Text = getCellData(dgvData, rowindex, 2);
            dtEntryDate.SelectedDate = Convert.ToDateTime(getCellData(dgvData, rowindex, 3));
            chkActive.IsChecked = getCellData(dgvData, rowindex, 4) == "Y";
        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow dataGridRow = dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(dataGridRow) as TextBlock;
            return cellContent.Text;
        }
    }
}
