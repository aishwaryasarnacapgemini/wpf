﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Admin admin = new Admin();
        AdminBL adminBL = new AdminBL();
        Employee employee = new Employee();
        EmployeeBL employeeBL = new EmployeeBL();

        private async Task<Admin> Admin_Login(object sender, RoutedEventArgs e)
        {
            try
            {
                admin = await adminBL.GetAdminByEmailAndPasswordBL(txtEmail.ToString(), txtPassword.ToString());
                Common.CurrentUserID = admin.AdminID;
                var adminHome = new Window1();
                adminHome.Show();
                this.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            return admin;
        }

        private async Task<Employee> Employee_Login(object sender, RoutedEventArgs e)
        {
            try
            {
                employee = await employeeBL.GetEmployeeByEmailAndPasswordBL(txtEmail.ToString(), txtPassword.ToString());
                Common.CurrentUserID = employee.EmployeeID;
                var employeeHome = new Window2();
                employeeHome.Show();
                this.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message); 
            }
            
            return employee;
        }

        
    }
}
